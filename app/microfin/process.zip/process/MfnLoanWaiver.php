<?php

	namespace App\microfin\process;

	use Illuminate\Database\Eloquent\Model;

	class MfnLoanWaiver extends Model {

		public $timestamps = false;
		protected $table = 'mfn_loan_waivers';
	}