
<!--***********************************************
* Programmer: Himel Dey                           *
* Ambala IT                                      *
* Topic: OTS Statement Report                    *
***********************************************!-->

<div id="printDiv">
    <!--This div is going to print company details and  ots account Statement   !-->
    <div class="row" style="padding-bottom: 10px; text-align: center; vertical-align: middle; color: black; font-weight: bold; "> {{-- div for Company --}}
           <?php
              $user_company_id = Auth::user()->company_id_fk;
              $company = DB::table('gnr_company')->where('id',$user_company_id)->select('name','address')->first();
           ?>
           <span style="font-size:14px;">{{$company->name}}</span><br/>
           <span style="font-size:11px;">{{$company->address}}</span><br/>
           <span style="text-decoration: underline;  font-size:14px;">OTS Account Statement</span></br>
           <?php
              $BranchName= DB::table('gnr_branch')
                          ->select('gnr_branch.name')
                          ->where('gnr_branch.id', '=', $Branch)
                          ->first();
           ?>
           <span style="text-decoration: none;  font-size:20px;">Branch:{{$BranchName->name}}</span>
    </div>
    <!--This row div ends here   !-->


    <div class="row">
      <!--This div is going to calculate initial ots account Information according to the accountNumber   !-->
       <div class="col-md-12" style="font-size: 12px;" >
         <?php
             $AccountNumber = DB::table('acc_ots_account')
                             ->join('acc_ots_member','acc_ots_account.id','=','acc_ots_member.id')
                             ->select('acc_ots_account.accNO','acc_ots_account.openingDate','acc_ots_member.*','acc_ots_account.status as accStatus')
                             ->where('acc_ots_account.id', '=', $accountNumber)
                             ->first();
         ?>
         <table style="width:100%; font-size: 12px;font-weight: bold; text-align: right; color:black;" id="information"  >
           <tbody>
            <tr>
              <td width="6%" style="text-align: left">Name</td>
              <td style="padding-right:10px">: </td>
              <td width="60%" style="text-align: left"> {{$AccountNumber->name}}</td>
              <td  style="text-align: right">Status</td>
              <td style="text-align: right">:</td>
              <td width="10%" style="text-align: right"><?php if($AccountNumber->accStatus == 1)
                                                     {echo "Open";}
                                                 else{echo "Closed";}?></td>
            </tr>


            <tr>
              <td style="text-align: left">Ph No</td>
              <td style="padding-right:10px">:</td>
              <td style="text-align: left">{{$AccountNumber->mobileNo}}</td>
              <td style="text-align: right">Address</td>
              <td style="text-align: right">:</td>
              <td style="text-align: right"> {{ $AccountNumber->address}}</td>
           </tr>


          <tr>
            <td style="text-align: left"> Acc No</td>
            <td style="padding-right:10px">:</td>
            <td style="text-align: left">{{ $AccountNumber->accNO}}</td>
            <td style="text-align: right">Print Date</td>
            <td style="text-align: right">:</td>
            <td style="text-align: right; "><?php  echo date("Y/m/d") ."  ".date("h:i:sa"); ?></td>



        </tr>

        </tbody>

     </table>
    </div>
  </div>




    <div class="row">
    	<div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-striped table-bordered" id="reportingTable" border="1pt solid ash" style="color:black; border-collapse: collapse;/*table-layout: fixed;*/ " >
                    <thead>
                        <tr>
                            <th rowspan="2">Date</th>
                            <th rowspan="2">Narration</th>
                            <th rowspan="2">Trans Type</th>
                          <!--  <th colspan="2">Current Period</th>
                            {{-- <th>Debit Amount</th>
                            <th>Credit Amount</th> --}} !-->
                            <th>Debit Amount</th>
                            <th>Credit Amount</th>
                            <th rowspan="2">Balance</th>
                        </tr>
                        <tr></tr>

                    </thead>

                    <tbody>
                      <tr>
                          <td class="name">{{$openingBalanceAmount->name}}</td>
                          <td class="name"></td>
                          {{-- <td class="amount"></td> --}}
                          <td  class="amount openingBalance" amount=""></td>
                          {{-- <td class="amount"></td> --}}
                          {{-- <td class="amount"></td> --}}
                          <td  class="amount debitAmount" amount=""></td>
                          {{-- <td class="amount"></td> --}}
                          <td  class="amount creditAmount" amount=""></td>
                          {{-- <td class="amount"></td> --}}
                          <td  class="amount closingBalance" amount="">{{ $sum}}.00</td>
                      </tr>
                    <?php
                         $max=sizeof($traDateArray);
                         $debit=0;
                         $credit=0;
                         for ($x = 0; $x <$max; $x++) {  ?>
                           <?php
                              $payment= DB::table('acc_ots_payment_details')
                                        ->select('id')
                                        ->where('paymentDate', '=', $traDateArray[$x])
                                        ->where('accId_fk','=',$accountNumber)
                                        ->first();

                            $interest= DB::table('acc_ots_interest_details')
                                       ->select('id')
                                       ->where('generateDate', '=', $traDateArray[$x])
                                       ->where('accId_fk','=',$accountNumber)
                                       ->first();
                          ?>

                          <?php
                            if($payment){?>
                               <tr>
                                 <td class="name">
                                   <?php  echo $traDateArray[$x];  ?>
                                 </td>
                                <td class="name">
                                   Money Widraw Occured
                                </td>
                                <td  class="name" >
                                   <?php
                                      echo "Widraw";
                                   ?>
                                 </td>

                        <td  class="amount debitAmount" amount="">  <?php $payment= DB::table('acc_ots_payment_details')
                           ->select('amount')
                           ->where('id', '=', $payment->id)

                           ->first();
                           echo $payment->amount;echo ".00";

                           $debit=$debit+ $payment->amount;
                           $sum=$sum-$payment->amount;


                           ?></td>

                        <td  class="amount creditAmount" amount="">0.00</td>

                        <td  class="amount closingBalance" amount="">{{$sum}}.00</td>
                      </tr>
                      <?php }?>



                      <?php    if($interest){    ?>
                         <tr>
                        <td class="name">
                        <?php  echo $traDateArray[$x];  ?>
                      </td>
                      <td class="name">
                         Auto Interest Added With Balance
                      </td>
                      {{-- <td class="amount"></td> --}}
                      <td  class="name">
                      <?php
                       echo "Deposit";
                      ?>
                      </td>

                      <td  class="amount debitAmount" amount="">0.00</td>

                      <td  class="amount creditAmount" amount=""><?php $interest= DB::table('acc_ots_interest_details')
                      ->select('amount')
                      ->where('id', '=', $interest->id)
                      ->first();
                      echo $interest->amount;echo ".00";
                      $credit=$credit+$interest->amount;

                      $sum=$sum+$interest->amount;

                      ?></td>

                      <td  class="amount closingBalance" amount="">{{$sum}}.00</td>
                      </tr>
                      <?php }?>


                      <?php }?>


                      <tr> </tr>





                    </tbody>
                    <tfoot>
                        <tr>
                          <td colspan="3" class="name" style="font-weight: bold; text-align:center;">Total</td>
                          <td  class="amount debitAmount" style="font-weight: bold; padding-right:3px; text-align:right;"amount="">{{$debit}}.00</td>

                          <td  class="amount creditAmount" style="font-weight: bold;padding-right:3px;text-align:right;"amount="">{{$credit}}.00</td>

                          <td  class="amount closingBalance" style="font-weight: bold;padding-right:3px;text-align:right;"amount="">{{$sum}}.00</td>
                        </tr>
                    </tfoot>



                </table>


            </div>      {{-- responseDIV --}}


    	</div>
    </div>



</div>
